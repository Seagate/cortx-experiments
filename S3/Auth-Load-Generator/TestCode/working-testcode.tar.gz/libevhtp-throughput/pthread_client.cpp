/*
 * Copyright (c) 2020 Seagate Technology LLC and/or its Affiliates
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * For any questions about this software or licensing,
 * please email opensource@seagate.com or cortx-questions@seagate.com.
 *
 */


/*
 * This program complements the 'server'.
 * It can send GET and PUT requests only.
 * GET request should have form http://<host>:60080/<size>
 * The server will return a correct HTTP responce
 * with 'size' bytes of zero as body.
 * The program can also send PUT requests
 * with a body of specified amount of zero-bytes.
 * The program uses 'libcurl' engine and requires 'libcurl-devel'
 * package for building and 'curl' package for running.
 */

#include <cstring>
#include <iostream>
#include <string>
#include <sstream>
#include <memory>
#include <exception>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <gflags/gflags.h>

#include <curl/curl.h>

#include "Config.hpp"
#include "SignApi.hpp"
#include <chrono>
//#include "Client.hpp"
#include "Request.hpp"

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <thread>
#include <pthread.h>

#define NUM_THREADS 600
const char sz_usage[] =
  "Usage: client [-put] [-port N] <server_IP> <size>\n"
  "'size' is a decimal number with opt. suffix: 'k', 'm' or 'g'\n";

DEFINE_bool(put, false, "Use PUT instead of GET");
DEFINE_int32(port, 60080, "TCP port for listerning connections");

const char *sz_ip;
static sockaddr_in sin;
static unsigned long file_size;
static unsigned long sent;
static unsigned long sz_thread;

std::string AmzTimestamp(time_t time) {
        char buffer[17];
        (void)strftime(buffer, sizeof(buffer), "%Y%m%dT%H%M%SZ", gmtime(&time));
        return buffer;
    }

static size_t read_callback(
    char *pb,
    size_t size,
    size_t nitems,
    void *p_user_data)
{
  auto len = size * nitems;
  auto rest = file_size - sent;

  if ( len > rest )
  {
    len = rest;
  }
  if ( len )
  {
    memset(pb, 0, len);
    sent += len;
  }
  return len;
std::cout << "Read Callback";
}

static size_t write_callback(
    char *ptr,
    size_t size,
    size_t nmemb,
    void *p_userdata)
{
  return size * nmemb;
}

static int parse_args(int argc, char **argv)
{
  if (argc < 3 || argc > 5)
  {
    return 1;
  }
  int idx = 1;

  sz_thread = strtol(argv[idx], NULL, 10);
  //sz_thread = argv[idx];
    ++idx;
  char *sz_arg = argv[idx];

  if ( ! inet_aton(sz_arg, &sin.sin_addr))
  {
    return 1;
  }
  sz_ip = sz_arg;
 ++idx; 
 //if (argc < ++idx)
  //{
   // return 1;
  //}
  sz_arg = argv[idx];

  std::string s_arg(sz_arg);
  size_t suffix_offset = 0;

  try
  {
    file_size = std::stoul(s_arg, &suffix_offset);
  }
  catch( const std::exception& ex )
  {
    std::cout << ex.what();
    return 1;
  }
  catch ( ... )
  {
    std::cout << "Unknown exception\n";
    return 1;
  }
  if ( suffix_offset + 1 == s_arg.length())
  {
    switch ( s_arg[ suffix_offset ] )
    {
      case 'k':
      case 'K':
        file_size *= 1024;
        break;
      case 'm':
      case 'M':
        file_size *= 1024 * 1024;
        break;
      case 'g':
      case 'G':
        file_size *= 1024 * 1024 * 1024;
    }
  }
  else if ( suffix_offset != s_arg.length())
  {
    return 1;
  }
  return 0;

  file_size = std::stoul(s_arg, &suffix_offset);
}

static std::string build_url()
{
  std::ostringstream oss;

  oss << "https://" << sz_ip << ":" << FLAGS_port << "/" << file_size;
  //oss << "http://" << 172.19.6.54 << ":" << 5001;

  return oss.str();
}

char str[150]={0};
char str2[1024]={0};
char str3[2048]={0};
pthread_t tid[4040];
int error;

static void *pull_one_url(void *td);
int main(int argc, char **argv)
{
 	 gflags::SetUsageMessage(sz_usage);
	  gflags::ParseCommandLineFlags(&argc, &argv, true);

  	if (parse_args(argc, argv))
  	{
    		std::cout << sz_usage;
    		return 1;
	}	
        std::string region = "us-west2";
        //std::string accessKeyId = "AKIANklWrCGNSQW0EAE7D0RJbA";
        std::string accessKeyId = "sgiamadmin";
        //std::string secretAccessKey = "c7cObNQpnLapHBYiZkxKT5xqK1/4OgN3uyNp7s9R";
        //std::string secretAccessKey = "ldapadmin";
        std::string secretAccessKey = "2UwrR13YIDhU";
        const auto host = "iam.seagate.com";
        const auto date = AmzTimestamp(time(NULL));
        Http::Request request;
        request.method = "POST";
        request.target.SetHost(host);
        request.target.SetPort(9080);
        request.target.SetPath({""});
        request.headers.AddHeader("Host", host);
        request.headers.AddHeader("x-amz-date", date);

       //std::cout<<"Before canonical request";
        const auto canonicalRequest = Aws::SignApi::ConstructCanonicalRequest(request.Generate());
        //std::cout<<"After canonical request";
        const auto payloadHashOffset = canonicalRequest.find_last_of('\n') + 1;
        const auto payloadHash = canonicalRequest.substr(payloadHashOffset);
        //std::cout<<"Before String to sign";
        const auto stringToSign = Aws::SignApi::MakeStringToSign(
            region,
            "iam",
            canonicalRequest
        );

        //std::cout<<"After string to sign";
        //std::cout<<"Before Make autorization";
        const auto authorization = Aws::SignApi::MakeAuthorization(
            stringToSign,
            canonicalRequest,
            accessKeyId,
            secretAccessKey
        );
	strcat(str, "x-amz-date:");
	strcat(str, date.c_str());

	strcat(str2, "x-amz-content-sha256:");
	strcat(str2,payloadHash.c_str());

	strcat(str3, "Authorization:"); 
	strcat(str3,authorization.c_str());

	int i;
        std::cout<<("Num of threads\n",sz_thread);
	 for(i=0; i< sz_thread; i++) {
		           error = pthread_create(&tid[i],
                           NULL, /* default attributes please */ 
                           pull_one_url,
                           NULL);
	if(0 != error)
			std::cout << ("Thread Error\n");
//      		fprintf(stderr, "Couldn't run thread number %d, errno %d\n", i, error);
//    	else
//			std::cout<<("Thread successfull\n");
  //    		fprintf(stderr, "Thread %d, gets %s\n", i, https[i].gepic);
  	}	
 
  /* now wait for all threads to terminate */ 
  for(i=0; i< sz_thread; i++) {
    error = pthread_join(tid[i], NULL);
    //fprintf(stderr, "Thread %d terminated\n", i);
    std::cout<<("Thread %d terminated\n", i);
  }

//  if (FLAGS_put)
//  {
//    curl_easy_setopt(sp_curl.get(), CURLOPT_UPLOAD, 1);

/*    curl_easy_setopt(sp_curl.get(),
        CURLOPT_INFILESIZE_LARGE,
        (curl_off_t)file_size);*/


 //   curl_easy_setopt(sp_curl.get(), CURLOPT_POST, 1);

//    curl_setopt(sp_curl.get(), CURLOPT_POSTFIELDS, $postdata);

 return 0;
}


static void *pull_one_url(void *td)
{
	int i;
	for(i=0;i<1;i++)
	{
	std::unique_ptr<CURL, decltype(&curl_easy_cleanup)> sp_curl(
	curl_easy_init(),&curl_easy_cleanup);
	std::string s_url = build_url();
		//	std::cout << "URL: " << s_url << '\n';
	struct curl_slist *p_headers_list = NULL;

	curl_easy_setopt(sp_curl.get(), CURLOPT_URL, s_url.c_str());
//	curl_easy_setopt(sp_curl.get(), CURLOPT_SSL_VERIFYPEER, false);	
	curl_easy_setopt(sp_curl.get(), CURLOPT_CAINFO , '/etc/ssl/stx-s3-clients/s3/ca.crt');
	curl_easy_setopt(sp_curl.get(), CURLOPT_POSTFIELDS, "Action=ListAccounts&ShowAll=False");

	p_headers_list = curl_slist_append(p_headers_list,"Host: iam.seagate.com");
//	p_headers_list = curl_slist_append(p_headers_list, "Content-Length:");
	p_headers_list = curl_slist_append(p_headers_list, "User-Agent: aws-cli/1.18.222 Python/3.6.8 Linux/3.10.0-1127.el7.x86_64 botocore/1.19.62");
	p_headers_list = curl_slist_append(p_headers_list, "Accept-Encoding:identity");

	p_headers_list = curl_slist_append(p_headers_list, str);
	p_headers_list = curl_slist_append(p_headers_list, str2);
	p_headers_list = curl_slist_append(p_headers_list, str3);
	
/*	curl_easy_setopt(sp_curl.get(),
        CURLOPT_READFUNCTION,
        &read_callback);*/
  	p_headers_list = curl_slist_append(
        p_headers_list, "Connection: close");

	curl_easy_setopt(sp_curl.get(), CURLOPT_HTTPHEADER, p_headers_list);

  	auto ret = curl_easy_perform(sp_curl.get());

  	curl_slist_free_all(p_headers_list);

  	if ( CURLE_OK != ret )
  	{
    		std::cout << curl_easy_strerror(ret);
  	}
 }
  return 0;
}
