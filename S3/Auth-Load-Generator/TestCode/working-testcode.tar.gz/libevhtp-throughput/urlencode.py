import urllib.parse
body = urllib.parse.urlencode({'Action' : 'ListAccounts', 'ShowAll' : 'showAll'})

print(body)
