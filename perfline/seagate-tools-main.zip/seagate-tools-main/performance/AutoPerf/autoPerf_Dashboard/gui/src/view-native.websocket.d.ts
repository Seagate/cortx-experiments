declare module "vue-native-websocket";
