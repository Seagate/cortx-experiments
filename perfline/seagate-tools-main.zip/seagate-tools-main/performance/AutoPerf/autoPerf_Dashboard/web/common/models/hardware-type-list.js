module.exports = {
  hardwareTypeList: [
    {
      name: 'EES-2Node-1-PODS',
    },
    {
      name: 'EES-2Node-1-5u84',
    },
    {
      name: 'EES-2Node-1-5u84',
    },
    {
      name: 'ECS-12Node-12-5u84',
    },
    {
      name: 'EES-2Node-1-5u84',
    },
    {
      name: 'EES-2Node-1-5u84',
    },
  ],
};
