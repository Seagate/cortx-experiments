#!/bin/bash

"$@" 2>&1