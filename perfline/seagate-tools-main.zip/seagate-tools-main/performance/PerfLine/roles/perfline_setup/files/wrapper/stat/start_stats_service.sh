#!/bin/bash

set -x

CLUSTER_CONFIG_FILE="/var/lib/hare/cluster.yaml"
ASSIGNED_IPS=$(ifconfig | grep inet | awk '{print $2}')
SCRIPT_PATH="$(readlink -f $0)"
SCRIPT_DIR="${SCRIPT_PATH%/*}"
RESULT=$(python3 $SCRIPT_DIR/extract_disks.py $CLUSTER_CONFIG_FILE $ASSIGNED_IPS)
DISKS=`echo "$RESULT" | grep 'IO:' | sed 's/IO://'`

function removing_dir()
{
     rm -rf /var/perfline/iostat.$(hostname -s) || true
     rm -rf /var/perfline/dstat.$(hostname -s) || true
     rm -rf /var/perfline/blktrace.$(hostname -s) || true
     rm -rf /var/perfline/glances.$(hostname -s) || true
}

function creating_dir()
{
     mkdir -p /var/perfline/iostat.$(hostname -s)
     mkdir -p /var/perfline/dstat.$(hostname -s)
     mkdir -p /var/perfline/blktrace.$(hostname -s)
     mkdir -p /var/perfline/glances.$(hostname -s)
}

echo "stat collection: $1"
removing_dir    
creating_dir
if [[ "$1" == *"IOSTAT"* ]]
then
     iostat -yxmt 1 > /var/perfline/iostat.$(hostname -s)/iostat.log & 
     echo "iostat collection started"
fi
sleep 5

if [[ "$1" == *"DSTAT"* ]]
then
    dstat --full --output /var/perfline/dstat.$(hostname -s)/dstat.csv > /dev/null &
    echo "dstat collection started"
fi
sleep 5

if [[ "$1" == *"GLANCES"* ]]
then
    csv_file="/var/perfline/glances.$(hostname -s)/glances.csv"
    glances --quiet --export csv --export-csv-file $csv_file &
    echo "Glances collection started"
fi
sleep 5

if [[ "$1" == *"BLKTRACE"* ]]
then
    echo "blktrace collection starting"
    blktrace $DISKS -D /var/perfline/blktrace.$(hostname -s) 
fi

